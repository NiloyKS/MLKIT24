package com.example.caferio

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
